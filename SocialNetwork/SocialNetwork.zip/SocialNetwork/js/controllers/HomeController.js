'use strict';

app.controller('HomeController', ['$scope', function($scope) {

}]);